# 예시 ERD 초안 (1번 Backend Entity 기준 — 2번 ERD와 맞춰 확정)

```mermaid
erDiagram
    users ||--o{ user_interest_field : "관심 분야 1~3"
    users ||--o{ user_company_size : "희망 기업 규모"
    users ||--o{ user_weekly_availability : "요일별 공부시간"
    users ||--o{ calendar_event : "일정"
    field_category ||--o{ certificate : ""
    field_category ||--o{ job_posting : ""
    company ||--o{ job_posting : ""
    job_posting ||--o{ job_posting_certificate : ""
    certificate ||--o{ job_posting_certificate : "필수/우대"
    certificate ||--o{ exam_schedule : "회차"

    users {
        bigint id PK
        varchar email UK
        varchar password_hash
        varchar nickname
        datetime created_at
    }
    user_interest_field {
        bigint user_id FK
        bigint field_id
    }
    user_company_size {
        bigint user_id FK
        varchar company_size "SME|MID|LARGE|UNKNOWN"
    }
    user_weekly_availability {
        bigint user_id FK
        varchar day_of_week
        int available_minutes
    }
    field_category {
        bigint id PK
        varchar code UK
        varchar name
        boolean cbt_supported
    }
    company {
        bigint id PK
        varchar name
        varchar company_size "공식 분류"
        varchar asset_band "참고 구간(별도)"
        varchar region
        varchar industry
        int regular_worker_count
        varchar size_source "출처"
        date size_base_date "기준일"
    }
    job_posting {
        bigint id PK
        varchar title
        bigint company_id FK
        bigint field_id FK
        varchar source
        date posted_date
    }
    job_posting_certificate {
        bigint id PK
        bigint job_posting_id FK
        bigint certificate_id FK
        varchar requirement_type "REQUIRED|PREFERRED"
    }
    certificate {
        bigint id PK
        varchar code UK "고용24 certCd"
        varchar name
        bigint field_id FK
        double average_pass_rate
        varchar pass_rate_basis
        boolean mock_diagnosis_supported
    }
    exam_schedule {
        bigint id PK
        bigint certificate_id FK
        varchar round_name
        date registration_start
        date registration_end
        date exam_date
    }
    calendar_event {
        bigint id PK
        bigint user_id
        varchar title
        date event_date
        int planned_minutes
        varchar event_type "STUDY|DIAGNOSIS|EXAM|CUSTOM"
        bigint certificate_id
        bigint study_plan_id "자동 생성 묶음(3단계)"
        boolean completed
    }
```

## 2번 담당 테이블 (2~3단계, 아직 Entity 없음)
- `cbt_question` (field_id, 문항, 보기, 정답, 개념 태그), `cbt_result`
- `mock_question` (certificate_id, 영역 태그 ...), `mock_result` (총점, 영역별 정답률)
- `study_plan` (학습 부담도 L, 취약도, 단계, 시험 회차), `study_plan_history` (재조정 이력)
- `calendar_event.study_plan_id`로 자동 생성 일정과 연결 → 재조정 시 남은 일정만 교체

## 고용24 API ↔ 컬럼 매핑 (2번 수집 코드 기준)

| 2번 코드 | 응답 태그 | 저장 위치 |
|---|---|---|
| 강소기업 API `callOpenApiSvcInfo216L01` | `coNm` | company.name |
| | `regionNm` | company.region |
| | `indTpNm` | company.industry |
| | `alwaysWorkerCnt` | company.regular_worker_count |
| | `selYear` | company.size_base_date (선정연도) |
| | (API 자체) | company.size_source = "고용24 강소기업", company_size = SME (선정 요건 확인 후) |
| 공통코드 API `dtlGb=3` (자격면허코드) | `certCd`, `certNm` | certificate.code, certificate.name |
| 공통코드 API `dtlGb=1` (지역코드) | `regionCd`, `regionNm` | (필요 시) 지역 필터 |
| 직업정보 API `212L01` | `jobCd`, `jobNm` | (선택) 분야 ↔ 직업 매핑 |
| 직무정보 API `215L01` (NCS) | `job_lcfn`, `knwg_tchn_attd` | (2번) CBT 문항 개념 태그 근거 |

> 강소기업 목록에는 중견·대기업 정보가 없으므로 MID/LARGE는 별도 출처(중견기업 확인정보, 공시대상기업집단)가 필요합니다. 출처가 없으면 UNKNOWN으로 둡니다.
