# Recommender Calendar — Backend

관심 분야·기업 규모 기반 자격증 추천 + 적응형 학습 캘린더 서비스의 백엔드 (Spring Boot 3.3 / Java 17).

## 실행

```bash
# 1) 설치 없이 바로 실행 (H2 인메모리 DB + 샘플 데이터)
./gradlew bootRun

# 2) 로컬 MySQL로 실행
#    mysql> CREATE DATABASE reccal DEFAULT CHARACTER SET utf8mb4;
DB_USERNAME=root DB_PASSWORD=비밀번호 ./gradlew bootRun --args='--spring.profiles.active=local'

# 테스트 (GitHub Actions에서도 이 명령 사용)
./gradlew test
```

- Swagger UI: http://localhost:8080/swagger-ui.html
- H2 콘솔: http://localhost:8080/h2-console (JDBC URL `jdbc:h2:mem:reccal`, user `sa`)

## 프로젝트 구조

```
src/main/java/com/reccal
├── common          공통 응답(ApiResponse), 예외 처리, Swagger·비밀번호 설정
├── user            회원가입·로그인, 관심 분야/희망 기업 규모, 요일별 공부 가능 시간
├── field           관심 분야 8개 대분류
├── company         기업, 기업 규모(CompanySize)·자산 참고 구간(AssetBand)
├── jobposting      채용공고 + 공고별 자격증(필수/우대), 기업 규모 필터(Specification)
├── certificate     자격증, 시험 회차
├── recommendation  자격증 추천 (CertificateRecommender 인터페이스 ← 2번 알고리즘 교체 지점)
└── calendar        캘린더 일정 CRUD, 완료 체크
src/main/resources
├── application.yml / application-h2.yml / application-local.yml
└── data.sql        발표용 샘플 데이터 (가상 기업, 샘플 합격률)
docs
├── API.md                     API 명세
├── ERD-draft.md, erd-draft.png Entity 기준 ERD 초안 + 고용24 API 매핑
└── role-agreement-with-2.md   1번↔2번 역할 경계 합의안
```

각 도메인 패키지는 `domain / dto / repository / service / controller` 순으로 나눈다.

## 현재 범위 (10/12 발표 기준)

- 회원, 관심 분야, 기업 규모 필터, 채용공고, 자격증, 추천(기본 알고리즘), 캘린더 API 동작
- 인증은 임시로 `X-User-Id` 헤더 사용 → 2단계에서 JWT
- 데이터는 샘플. 2번의 고용24 수집 데이터로 교체 예정
- CBT·모의진단·학습 일정 생성·재조정 API는 2~3단계 (docs/API.md 목록 참고)
