# Recommender Calendar API 명세 (v0.1, 10/12 발표용 초안)

- Base URL: `http://localhost:8080`
- Swagger UI: `http://localhost:8080/swagger-ui.html` (실행 후 바로 테스트 가능)
- 인증(임시): 로그인 응답의 `userId`를 `X-User-Id` 헤더로 보냄. JWT는 2단계에서 도입.
- 날짜 형식: `YYYY-MM-DD`

## 공통 응답 형식

```json
// 성공
{ "success": true, "data": { ... }, "error": null }
// 실패
{ "success": false, "data": null, "error": { "code": "INVALID_INPUT", "message": "..." } }
```

| HTTP | error.code | 상황 |
|---|---|---|
| 400 | INVALID_INPUT | 입력값 오류 (관심 분야 4개 이상, 잘못된 날짜 등) |
| 401 | MISSING_USER_HEADER / LOGIN_FAILED | 헤더 누락 / 로그인 실패 |
| 403 | FORBIDDEN | 다른 사용자의 일정 수정·삭제 |
| 404 | USER_NOT_FOUND, FIELD_NOT_FOUND, CERTIFICATE_NOT_FOUND, EVENT_NOT_FOUND | 대상 없음 |
| 409 | DUPLICATE_EMAIL | 이미 가입된 이메일 |

## API 목록

| # | 영역 | Method | URL | 헤더 | 상태 |
|---|---|---|---|---|---|
| 1 | 회원 | POST | `/api/auth/signup` | | 구현 |
| 2 | 회원 | POST | `/api/auth/login` | | 구현 |
| 3 | 회원 | GET | `/api/users/me` | X-User-Id | 구현 |
| 4 | 회원 | PUT | `/api/users/me/preferences` | X-User-Id | 구현 |
| 5 | 회원 | PUT | `/api/users/me/availability` | X-User-Id | 구현 |
| 6 | 관심 분야 | GET | `/api/fields` | | 구현 |
| 7 | 기업 필터 | GET | `/api/meta/company-sizes` | | 구현 |
| 8 | 기업 필터 | GET | `/api/meta/asset-bands` | | 구현 |
| 9 | 채용공고 | GET | `/api/job-postings` | | 구현 |
| 10 | 자격증 | GET | `/api/certificates` | | 구현 |
| 11 | 자격증 | GET | `/api/certificates/{certificateId}` | | 구현 |
| 12 | 추천 | GET | `/api/recommendations/certificates` | | 구현 (기본 알고리즘) |
| 13 | 캘린더 | GET | `/api/calendar/events?from=&to=` | X-User-Id | 구현 |
| 14 | 캘린더 | POST | `/api/calendar/events` | X-User-Id | 구현 |
| 15 | 캘린더 | PATCH | `/api/calendar/events/{eventId}` | X-User-Id | 구현 |
| 16 | 캘린더 | DELETE | `/api/calendar/events/{eventId}` | X-User-Id | 구현 |
| 17 | 분야 CBT | GET | `/api/fields/{fieldId}/cbt` | | 2단계 (2번 문항·규칙) |
| 18 | 분야 CBT | POST | `/api/fields/{fieldId}/cbt/submissions` | X-User-Id | 2단계 |
| 19 | 모의진단 | GET / POST | `/api/certificates/{id}/mock-diagnosis`, `/submissions` | X-User-Id | 3단계 |
| 20 | 학습 일정 | POST | `/api/study-plans` (목표 자격증·회차 → 일정 생성 → 캘린더 저장) | X-User-Id | 3단계 (2번 일정 로직) |
| 21 | 재조정 | POST | `/api/study-plans/{planId}/rebalance` | X-User-Id | 3단계 |

---

## 1. 회원

### POST /api/auth/signup → 201
```json
{ "email": "soo@example.com", "password": "password123", "nickname": "수" }
```
응답 `data`: 사용자 정보 (아래 GET /api/users/me와 동일 형식)

### POST /api/auth/login
```json
{ "email": "soo@example.com", "password": "password123" }
```
```json
{ "success": true, "data": { "userId": 1, "nickname": "수" }, "error": null }
```

### GET /api/users/me
```json
{
  "id": 1, "email": "soo@example.com", "nickname": "수",
  "interestFieldIds": [1, 3],
  "preferredCompanySizes": ["MID", "SME"],
  "weeklyAvailableMinutes": { "MONDAY": 120, "TUESDAY": 0, "...": 0, "SATURDAY": 240, "SUNDAY": 0 },
  "weeklyTotalMinutes": 360
}
```

### PUT /api/users/me/preferences
관심 분야 1~3개, 기업 규모는 복수 선택(빈 배열 = 전체).
```json
{ "fieldIds": [1, 3], "companySizes": ["SME", "MID"] }
```

### PUT /api/users/me/availability
요일별 공부 가능 시간(분). 빠진 요일은 0분.
```json
{ "minutesByDay": { "MONDAY": 120, "WEDNESDAY": 120, "SATURDAY": 240 } }
```

## 2. 관심 분야

### GET /api/fields
```json
[ { "id": 1, "code": "IT_SW", "name": "IT·소프트웨어", "description": "...", "cbtSupported": true }, ... ]
```
`cbtSupported=true`인 분야(최소 기능 4개)만 1차 기초 CBT 제공.

## 3. 기업 규모 필터

### GET /api/meta/company-sizes
```json
[ {"code":"SME","label":"중소기업"}, {"code":"MID","label":"중견기업"},
  {"code":"LARGE","label":"대기업"}, {"code":"UNKNOWN","label":"미확인·기타"} ]
```

### GET /api/meta/asset-bands
`UNDER_500B`, `FROM_500B_TO_10T`, `OVER_10T`, `UNKNOWN` + 라벨·경계 조건. 공식 판정 기준이 아닌 참고 필터.

**필터 규칙**
1. 기업 규모는 복수 선택, 아무것도 선택하지 않으면 전체 공고.
2. `UNKNOWN`(미확인)은 사용자가 직접 선택했을 때만 결과에 포함. 전체 조회일 때는 포함하되 `countByCompanySize`로 따로 표시.
3. 공식 규모(`companySize`)와 자산 참고 구간(`assetBand`)은 별도 필드·별도 파라미터.
4. 기업 규모는 "어떤 공고를 보여줄지"에만 쓰고, 시험 난이도 계산에는 넣지 않음.

## 4. 채용공고

### GET /api/job-postings?fieldIds=1,3&companySizes=SME,MID&assetBands=UNDER_500B
모든 파라미터 선택. 
```json
{
  "totalCount": 3,
  "countByCompanySize": { "SME": 3 },
  "postings": [
    {
      "id": 1, "title": "백엔드 개발자 (신입)", "fieldName": "IT·소프트웨어",
      "company": { "id": 1, "name": "(샘플)한빛소프트", "companySize": "SME", "companySizeLabel": "중소기업",
                   "assetBand": "UNDER_500B", "sizeSource": "고용24 강소기업 API(샘플)", "sizeBaseDate": "2026-01-01" },
      "certificates": [
        { "certificateId": 1, "name": "정보처리기사", "requirementType": "REQUIRED", "requirementLabel": "필수" },
        { "certificateId": 2, "name": "SQLD(SQL개발자)", "requirementType": "PREFERRED", "requirementLabel": "우대" }
      ],
      "source": "샘플", "postedDate": "2026-09-20"
    }
  ]
}
```

## 5. 자격증

### GET /api/certificates?fieldId=1
```json
[ { "id": 1, "code": null, "name": "정보처리기사", "fieldId": 1, "fieldName": "IT·소프트웨어",
    "averagePassRate": 0.24, "mockDiagnosisSupported": true, "nextExamDate": "2026-11-08" } ]
```
`code`는 고용24 공통코드(자격면허코드) `certCd`로 채울 예정.

### GET /api/certificates/{certificateId}
위 정보 + `issuer`, `passRateBasis`(합격률 근거), `examSchedules[]`(회차명, 접수기간, 시험일).

## 6. 자격증 추천

### GET /api/recommendations/certificates?fieldIds=1&companySizes=SME&limit=10
필터 조건은 채용공고 API와 동일.
```json
{
  "analyzedPostingCount": 3,
  "algorithm": "FrequencyBasedRecommender",
  "recommendations": [
    { "rank": 1, "certificateId": 1, "name": "정보처리기사", "fieldName": "IT·소프트웨어",
      "postingCount": 3, "requiredCount": 1, "preferredCount": 2, "appearanceRate": 1.0, "score": 4.0,
      "averagePassRate": 0.24, "mockDiagnosisSupported": true, "nextExamDate": "2026-11-08" }
  ]
}
```
기본 점수(초안): `필수 등장 × 2 + 우대 등장 × 1`. 2번이 `CertificateRecommender` 구현체로 교체.

## 7. 캘린더

### GET /api/calendar/events?from=2026-10-01&to=2026-10-31 (최대 366일)
### POST /api/calendar/events → 201
```json
{ "title": "SQL 개념 복습", "date": "2026-10-20", "plannedMinutes": 120,
  "type": "STUDY", "certificateId": 1, "memo": "조인 파트" }
```
`type`: `STUDY`(학습) / `DIAGNOSIS`(모의진단) / `EXAM`(시험) / `CUSTOM`(기타)

### PATCH /api/calendar/events/{eventId}
보낸 필드만 수정. 완료 체크: `{ "completed": true }`

### DELETE /api/calendar/events/{eventId}
