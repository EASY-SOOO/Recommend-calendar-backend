# 1번(Backend) ↔ 2번(DB/추천/CBT) 역할 경계 합의안 (초안)

## 1번이 맡는 것
- Spring Boot 프로젝트 구조, 공통 응답·예외 형식, Swagger
- Entity / Repository / Controller / Service (회원, 관심 분야, 기업, 채용공고, 자격증, 캘린더)
- 기업 규모 필터 API (`/api/job-postings`) 와 추천 API 껍데기 (`/api/recommendations/certificates`)
- CBT·모의진단·일정 생성 API의 Controller와 저장 처리 (2~3단계)

## 2번이 맡는 것
- ERD 확정 (1번 Entity 초안 `docs/ERD-draft.md`를 기준으로 수정 요청)
- 고용24 데이터 수집 → DB 적재용 데이터 (현재 `data.sql`의 샘플을 실데이터로 교체)
- 추천 알고리즘: `recommendation/CertificateRecommender` 인터페이스 구현체
- CBT 문항·진단 규칙, 학습 부담도 L = 0.7×부족도 + 0.3×난이도, 취약도, 일정 배분 로직

## 연결 방식 (코드 충돌 없이 나눠 작업)
- 추천: 2번이 `CertificateRecommender`를 구현하고 `@Primary`를 붙이면 Controller 수정 없이 교체됨
  ```java
  List<CertificateRecommendation> recommend(List<JobPosting> filteredPostings, int limit);
  ```
- 일정 생성(3단계 제안): `StudyPlanGenerator` 인터페이스
  - 입력: 진단 점수, 영역별 정답률, 평균 합격률, 시험일, 요일별 공부 가능 시간
  - 출력: 날짜별 학습 항목 리스트(제목, 날짜, 분, 단계) → 1번이 `calendar_event`로 저장

## 확인이 필요한 질문
1. 2번의 고용24 데이터는 Python으로 수집 → CSV/SQL로 넘겨줄지, Spring에서 직접 API 호출할지?
2. 채용공고 데이터 출처는? (강소기업 API는 기업 목록이라 공고·자격증 요건은 별도 필요)
3. 강소기업을 `SME`로 분류해도 되는지 (선정 요건 확인)
4. 중견·대기업 분류 출처를 무엇으로 할지, 없으면 UNKNOWN으로 둘지
5. 테이블·컬럼 이름 규칙: snake_case, 단수형(`company`, `certificate`)으로 통일해도 되는지
