package com.reccal.calendar.controller;

import com.reccal.calendar.dto.CreateEventRequest;
import com.reccal.calendar.dto.EventResponse;
import com.reccal.calendar.dto.UpdateEventRequest;
import com.reccal.calendar.service.CalendarService;
import com.reccal.common.response.ApiResponse;
import com.reccal.user.controller.UserController;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.time.LocalDate;
import java.util.List;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "7. 캘린더")
@RestController
@RequestMapping("/api/calendar/events")
public class CalendarController {

    private final CalendarService calendarService;

    public CalendarController(CalendarService calendarService) {
        this.calendarService = calendarService;
    }

    @Operation(summary = "기간별 일정 조회", description = "예: ?from=2026-10-01&to=2026-10-31 (최대 366일)")
    @GetMapping
    public ApiResponse<List<EventResponse>> list(
            @RequestHeader(UserController.USER_HEADER) Long userId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {
        return ApiResponse.ok(calendarService.list(userId, from, to));
    }

    @Operation(summary = "일정 추가")
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ApiResponse<EventResponse> create(@RequestHeader(UserController.USER_HEADER) Long userId,
                                             @Valid @RequestBody CreateEventRequest request) {
        return ApiResponse.ok(calendarService.create(userId, request));
    }

    @Operation(summary = "일정 수정·완료 체크", description = "보낸 필드만 수정. 완료 체크: {\"completed\": true}")
    @PatchMapping("/{eventId}")
    public ApiResponse<EventResponse> update(@RequestHeader(UserController.USER_HEADER) Long userId,
                                             @PathVariable Long eventId,
                                             @Valid @RequestBody UpdateEventRequest request) {
        return ApiResponse.ok(calendarService.update(userId, eventId, request));
    }

    @Operation(summary = "일정 삭제")
    @DeleteMapping("/{eventId}")
    public ApiResponse<Void> delete(@RequestHeader(UserController.USER_HEADER) Long userId,
                                    @PathVariable Long eventId) {
        calendarService.delete(userId, eventId);
        return ApiResponse.ok(null);
    }
}
