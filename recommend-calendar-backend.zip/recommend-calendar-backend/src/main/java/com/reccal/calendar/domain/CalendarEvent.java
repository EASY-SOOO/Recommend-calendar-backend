package com.reccal.calendar.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import java.time.LocalDate;

/**
 * 캘린더 일정 한 건. 일정 생성 로직(2번)이 만든 학습 일정도 이 형태로 저장된다.
 * studyPlanId: 같은 자동 생성 일정 묶음 (재조정 시 남은 일정만 교체하기 위함, 다음 단계에서 사용)
 */
@Entity
@Table(name = "calendar_event", indexes = @Index(name = "idx_event_user_date", columnList = "user_id, event_date"))
public class CalendarEvent {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(nullable = false, length = 100)
    private String title;

    @Column(name = "event_date", nullable = false)
    private LocalDate date;

    private Integer plannedMinutes;

    @Enumerated(EnumType.STRING)
    @Column(name = "event_type", nullable = false, length = 20)
    private EventType type;

    private Long certificateId;

    private Long studyPlanId;

    @Column(length = 500)
    private String memo;

    @Column(nullable = false)
    private boolean completed;

    protected CalendarEvent() {
    }

    public CalendarEvent(Long userId, String title, LocalDate date, Integer plannedMinutes, EventType type,
                         Long certificateId, String memo) {
        this.userId = userId;
        this.title = title;
        this.date = date;
        this.plannedMinutes = plannedMinutes;
        this.type = type;
        this.certificateId = certificateId;
        this.memo = memo;
        this.completed = false;
    }

    public void update(String title, LocalDate date, Integer plannedMinutes, String memo, Boolean completed) {
        if (title != null) {
            this.title = title;
        }
        if (date != null) {
            this.date = date;
        }
        if (plannedMinutes != null) {
            this.plannedMinutes = plannedMinutes;
        }
        if (memo != null) {
            this.memo = memo;
        }
        if (completed != null) {
            this.completed = completed;
        }
    }

    public Long getId() {
        return id;
    }

    public Long getUserId() {
        return userId;
    }

    public String getTitle() {
        return title;
    }

    public LocalDate getDate() {
        return date;
    }

    public Integer getPlannedMinutes() {
        return plannedMinutes;
    }

    public EventType getType() {
        return type;
    }

    public Long getCertificateId() {
        return certificateId;
    }

    public Long getStudyPlanId() {
        return studyPlanId;
    }

    public String getMemo() {
        return memo;
    }

    public boolean isCompleted() {
        return completed;
    }
}
