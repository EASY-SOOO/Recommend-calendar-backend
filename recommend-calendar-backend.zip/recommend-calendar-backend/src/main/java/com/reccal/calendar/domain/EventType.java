package com.reccal.calendar.domain;

public enum EventType {
    STUDY("학습"),
    DIAGNOSIS("모의진단"),
    EXAM("시험"),
    CUSTOM("기타");

    private final String label;

    EventType(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
