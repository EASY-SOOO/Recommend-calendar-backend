package com.reccal.calendar.dto;

import com.reccal.calendar.domain.EventType;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;

public record CreateEventRequest(
        @NotBlank @Size(max = 100) String title,
        @NotNull LocalDate date,
        @Min(0) @Max(1440) Integer plannedMinutes,
        @NotNull EventType type,
        Long certificateId,
        @Size(max = 500) String memo) {
}
