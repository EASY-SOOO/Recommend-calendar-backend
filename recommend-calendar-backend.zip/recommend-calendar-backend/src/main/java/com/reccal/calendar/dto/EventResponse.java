package com.reccal.calendar.dto;

import com.reccal.calendar.domain.CalendarEvent;
import java.time.LocalDate;

public record EventResponse(
        Long id,
        String title,
        LocalDate date,
        Integer plannedMinutes,
        String type,
        String typeLabel,
        Long certificateId,
        Long studyPlanId,
        String memo,
        boolean completed) {

    public static EventResponse from(CalendarEvent e) {
        return new EventResponse(e.getId(), e.getTitle(), e.getDate(), e.getPlannedMinutes(), e.getType().name(),
                e.getType().getLabel(), e.getCertificateId(), e.getStudyPlanId(), e.getMemo(), e.isCompleted());
    }
}
