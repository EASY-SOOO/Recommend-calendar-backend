package com.reccal.calendar.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;

/** 부분 수정: null인 필드는 그대로 둔다. 완료 체크는 { "completed": true } */
public record UpdateEventRequest(
        @Size(min = 1, max = 100) String title,
        LocalDate date,
        @Min(0) @Max(1440) Integer plannedMinutes,
        @Size(max = 500) String memo,
        Boolean completed) {
}
