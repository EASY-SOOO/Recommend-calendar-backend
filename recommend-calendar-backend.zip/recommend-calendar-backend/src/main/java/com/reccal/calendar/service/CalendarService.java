package com.reccal.calendar.service;

import com.reccal.calendar.domain.CalendarEvent;
import com.reccal.calendar.dto.CreateEventRequest;
import com.reccal.calendar.dto.EventResponse;
import com.reccal.calendar.dto.UpdateEventRequest;
import com.reccal.calendar.repository.CalendarEventRepository;
import com.reccal.certificate.repository.CertificateRepository;
import com.reccal.common.exception.BusinessException;
import com.reccal.common.exception.ErrorCode;
import com.reccal.user.repository.UserRepository;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(readOnly = true)
public class CalendarService {

    /** 한 번에 조회할 수 있는 최대 기간 (일) */
    private static final long MAX_RANGE_DAYS = 366;

    private final CalendarEventRepository eventRepository;
    private final UserRepository userRepository;
    private final CertificateRepository certificateRepository;

    public CalendarService(CalendarEventRepository eventRepository, UserRepository userRepository,
                           CertificateRepository certificateRepository) {
        this.eventRepository = eventRepository;
        this.userRepository = userRepository;
        this.certificateRepository = certificateRepository;
    }

    public List<EventResponse> list(Long userId, LocalDate from, LocalDate to) {
        if (from.isAfter(to)) {
            throw new BusinessException(ErrorCode.INVALID_INPUT, "from은 to보다 늦을 수 없습니다.");
        }
        if (ChronoUnit.DAYS.between(from, to) > MAX_RANGE_DAYS) {
            throw new BusinessException(ErrorCode.INVALID_INPUT, "조회 기간은 최대 " + MAX_RANGE_DAYS + "일입니다.");
        }
        ensureUser(userId);
        return eventRepository.findByUserIdAndDateBetweenOrderByDateAscIdAsc(userId, from, to).stream()
                .map(EventResponse::from).toList();
    }

    @Transactional
    public EventResponse create(Long userId, CreateEventRequest request) {
        ensureUser(userId);
        if (request.certificateId() != null && !certificateRepository.existsById(request.certificateId())) {
            throw new BusinessException(ErrorCode.CERTIFICATE_NOT_FOUND);
        }
        CalendarEvent event = new CalendarEvent(userId, request.title().trim(), request.date(),
                request.plannedMinutes(), request.type(), request.certificateId(), request.memo());
        return EventResponse.from(eventRepository.save(event));
    }

    @Transactional
    public EventResponse update(Long userId, Long eventId, UpdateEventRequest request) {
        CalendarEvent event = getOwnedEvent(userId, eventId);
        event.update(request.title(), request.date(), request.plannedMinutes(), request.memo(), request.completed());
        return EventResponse.from(event);
    }

    @Transactional
    public void delete(Long userId, Long eventId) {
        eventRepository.delete(getOwnedEvent(userId, eventId));
    }

    private CalendarEvent getOwnedEvent(Long userId, Long eventId) {
        CalendarEvent event = eventRepository.findById(eventId)
                .orElseThrow(() -> new BusinessException(ErrorCode.EVENT_NOT_FOUND));
        if (!event.getUserId().equals(userId)) {
            throw new BusinessException(ErrorCode.FORBIDDEN);
        }
        return event;
    }

    private void ensureUser(Long userId) {
        if (!userRepository.existsById(userId)) {
            throw new BusinessException(ErrorCode.USER_NOT_FOUND);
        }
    }
}
