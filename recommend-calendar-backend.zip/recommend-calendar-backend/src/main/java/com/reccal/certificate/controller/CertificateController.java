package com.reccal.certificate.controller;

import com.reccal.certificate.dto.CertificateDetail;
import com.reccal.certificate.dto.CertificateSummary;
import com.reccal.certificate.service.CertificateService;
import com.reccal.common.response.ApiResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "5. 자격증")
@RestController
@RequestMapping("/api/certificates")
public class CertificateController {

    private final CertificateService certificateService;

    public CertificateController(CertificateService certificateService) {
        this.certificateService = certificateService;
    }

    @Operation(summary = "자격증 목록", description = "fieldId를 주면 해당 분야만. 다음 시험일 포함")
    @GetMapping
    public ApiResponse<List<CertificateSummary>> list(@RequestParam(required = false) Long fieldId) {
        return ApiResponse.ok(certificateService.list(fieldId));
    }

    @Operation(summary = "자격증 상세", description = "평균 합격률(난이도 보정용)과 시험 회차 목록")
    @GetMapping("/{certificateId}")
    public ApiResponse<CertificateDetail> get(@PathVariable Long certificateId) {
        return ApiResponse.ok(certificateService.get(certificateId));
    }
}
