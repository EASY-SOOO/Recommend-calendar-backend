package com.reccal.certificate.domain;

import com.reccal.field.FieldCategory;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

/**
 * 자격증. code는 고용24 공통코드 API(자격면허코드, dtlGb=3)의 certCd와 연결한다.
 */
@Entity
@Table(name = "certificate")
public class Certificate {

    @Id
    private Long id;

    /** 고용24 공통코드 certCd (2번 데이터 수집 후 채움) */
    @Column(unique = true, length = 20)
    private String code;

    @Column(nullable = false, length = 100)
    private String name;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "field_id", nullable = false)
    private FieldCategory field;

    @Column(length = 100)
    private String issuer;

    /** 최근 평균 합격률 (0.0~1.0). 시험 난이도 보정용이며 개인 합격 확률이 아님 */
    private Double averagePassRate;

    /** 합격률 근거 (예: "최근 3개년 평균", 출처·기준연도) */
    @Column(length = 200)
    private String passRateBasis;

    /** 2차 목표 자격증 모의진단 지원 여부 (최소 기능은 1~2개) */
    @Column(nullable = false)
    private boolean mockDiagnosisSupported;

    protected Certificate() {
    }

    public Long getId() {
        return id;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public FieldCategory getField() {
        return field;
    }

    public String getIssuer() {
        return issuer;
    }

    public Double getAveragePassRate() {
        return averagePassRate;
    }

    public String getPassRateBasis() {
        return passRateBasis;
    }

    public boolean isMockDiagnosisSupported() {
        return mockDiagnosisSupported;
    }
}
