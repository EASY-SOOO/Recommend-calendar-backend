package com.reccal.certificate.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.time.LocalDate;

/** 자격증 시험 회차 */
@Entity
@Table(name = "exam_schedule")
public class ExamSchedule {

    @Id
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "certificate_id", nullable = false)
    private Certificate certificate;

    @Column(nullable = false, length = 50)
    private String roundName;

    private LocalDate registrationStart;

    private LocalDate registrationEnd;

    @Column(nullable = false)
    private LocalDate examDate;

    protected ExamSchedule() {
    }

    public Long getId() {
        return id;
    }

    public Certificate getCertificate() {
        return certificate;
    }

    public String getRoundName() {
        return roundName;
    }

    public LocalDate getRegistrationStart() {
        return registrationStart;
    }

    public LocalDate getRegistrationEnd() {
        return registrationEnd;
    }

    public LocalDate getExamDate() {
        return examDate;
    }
}
