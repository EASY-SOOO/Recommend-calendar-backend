package com.reccal.certificate.dto;

import com.reccal.certificate.domain.Certificate;
import com.reccal.certificate.domain.ExamSchedule;
import java.time.LocalDate;
import java.util.List;

public record CertificateDetail(
        Long id,
        String code,
        String name,
        Long fieldId,
        String fieldName,
        String issuer,
        Double averagePassRate,
        String passRateBasis,
        boolean mockDiagnosisSupported,
        List<ExamRound> examSchedules) {

    public record ExamRound(Long id, String roundName, LocalDate registrationStart, LocalDate registrationEnd,
                            LocalDate examDate) {

        public static ExamRound from(ExamSchedule s) {
            return new ExamRound(s.getId(), s.getRoundName(), s.getRegistrationStart(), s.getRegistrationEnd(),
                    s.getExamDate());
        }
    }

    public static CertificateDetail of(Certificate c, List<ExamSchedule> schedules) {
        return new CertificateDetail(c.getId(), c.getCode(), c.getName(), c.getField().getId(),
                c.getField().getName(), c.getIssuer(), c.getAveragePassRate(), c.getPassRateBasis(),
                c.isMockDiagnosisSupported(), schedules.stream().map(ExamRound::from).toList());
    }
}
