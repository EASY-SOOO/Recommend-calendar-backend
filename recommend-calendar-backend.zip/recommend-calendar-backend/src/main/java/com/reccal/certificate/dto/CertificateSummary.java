package com.reccal.certificate.dto;

import com.reccal.certificate.domain.Certificate;
import java.time.LocalDate;

public record CertificateSummary(
        Long id,
        String code,
        String name,
        Long fieldId,
        String fieldName,
        Double averagePassRate,
        boolean mockDiagnosisSupported,
        LocalDate nextExamDate) {

    public static CertificateSummary of(Certificate c, LocalDate nextExamDate) {
        return new CertificateSummary(c.getId(), c.getCode(), c.getName(), c.getField().getId(),
                c.getField().getName(), c.getAveragePassRate(), c.isMockDiagnosisSupported(), nextExamDate);
    }
}
