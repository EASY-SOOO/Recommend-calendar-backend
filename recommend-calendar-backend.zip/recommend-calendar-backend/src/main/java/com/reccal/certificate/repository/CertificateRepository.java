package com.reccal.certificate.repository;

import com.reccal.certificate.domain.Certificate;
import java.util.List;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CertificateRepository extends JpaRepository<Certificate, Long> {

    @EntityGraph(attributePaths = "field")
    List<Certificate> findAllByOrderByIdAsc();

    @EntityGraph(attributePaths = "field")
    List<Certificate> findByFieldIdOrderByIdAsc(Long fieldId);
}
