package com.reccal.certificate.repository;

import com.reccal.certificate.domain.ExamSchedule;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ExamScheduleRepository extends JpaRepository<ExamSchedule, Long> {

    List<ExamSchedule> findByCertificateIdOrderByExamDateAsc(Long certificateId);

    Optional<ExamSchedule> findFirstByCertificateIdAndExamDateGreaterThanEqualOrderByExamDateAsc(
            Long certificateId, LocalDate from);
}
