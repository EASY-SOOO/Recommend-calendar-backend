package com.reccal.certificate.service;

import com.reccal.certificate.domain.Certificate;
import com.reccal.certificate.dto.CertificateDetail;
import com.reccal.certificate.dto.CertificateSummary;
import com.reccal.certificate.repository.CertificateRepository;
import com.reccal.certificate.repository.ExamScheduleRepository;
import com.reccal.certificate.domain.ExamSchedule;
import com.reccal.common.exception.BusinessException;
import com.reccal.common.exception.ErrorCode;
import java.time.LocalDate;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(readOnly = true)
public class CertificateService {

    private final CertificateRepository certificateRepository;
    private final ExamScheduleRepository examScheduleRepository;

    public CertificateService(CertificateRepository certificateRepository,
                              ExamScheduleRepository examScheduleRepository) {
        this.certificateRepository = certificateRepository;
        this.examScheduleRepository = examScheduleRepository;
    }

    public List<CertificateSummary> list(Long fieldId) {
        List<Certificate> certificates = (fieldId == null)
                ? certificateRepository.findAllByOrderByIdAsc()
                : certificateRepository.findByFieldIdOrderByIdAsc(fieldId);
        return certificates.stream().map(c -> CertificateSummary.of(c, nextExamDate(c.getId()))).toList();
    }

    public CertificateDetail get(Long id) {
        Certificate certificate = certificateRepository.findById(id)
                .orElseThrow(() -> new BusinessException(ErrorCode.CERTIFICATE_NOT_FOUND));
        return CertificateDetail.of(certificate, examScheduleRepository.findByCertificateIdOrderByExamDateAsc(id));
    }

    /** 오늘 이후 가장 가까운 시험일 (없으면 null) */
    public LocalDate nextExamDate(Long certificateId) {
        return examScheduleRepository
                .findFirstByCertificateIdAndExamDateGreaterThanEqualOrderByExamDateAsc(certificateId, LocalDate.now())
                .map(ExamSchedule::getExamDate)
                .orElse(null);
    }
}
