package com.reccal.common.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI recommenderCalendarOpenApi() {
        return new OpenAPI().info(new Info()
                .title("Recommender Calendar API")
                .version("v0.1 (10/12 발표용 초안)")
                .description("관심 분야·기업 규모 기반 자격증 추천 및 학습 캘린더 API. "
                        + "로그인 후 받은 userId를 X-User-Id 헤더로 전달합니다(JWT 도입 전 임시 방식)."));
    }
}
