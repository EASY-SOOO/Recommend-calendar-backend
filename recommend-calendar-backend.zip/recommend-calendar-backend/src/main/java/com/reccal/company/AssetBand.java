package com.reccal.company;

/**
 * 자산 규모 참고 구간 (설계서 2.3). 기업 규모의 공식 판정 기준이 아니며, 별도 참고 필터로만 쓴다.
 */
public enum AssetBand {
    UNDER_500B("자산 5,000억 원 미만", "A < 5,000억 원"),
    FROM_500B_TO_10T("자산 5,000억 원 이상 ~ 10조 원 미만", "5,000억 원 ≤ A < 10조 원"),
    OVER_10T("자산 10조 원 이상", "A ≥ 10조 원"),
    UNKNOWN("자산 미확인", "자료가 없으면 추정하지 않음");

    private final String label;
    private final String condition;

    AssetBand(String label, String condition) {
        this.label = label;
        this.condition = condition;
    }

    public String getLabel() {
        return label;
    }

    public String getCondition() {
        return condition;
    }
}
