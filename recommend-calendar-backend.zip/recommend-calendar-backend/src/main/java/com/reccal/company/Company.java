package com.reccal.company;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;

/**
 * 기업 정보. 필드는 고용24 강소기업 API(callOpenApiSvcInfo216L01) 응답 태그와 대응된다.
 * coNm→name, regionNm→region, indTpNm→industry, alwaysWorkerCnt→regularWorkerCount, selYear→sizeBaseDate 근거.
 */
@Entity
@Table(name = "company")
public class Company {

    @Id
    private Long id;

    @Column(nullable = false, length = 100)
    private String name;

    /** 공식 기업 규모 분류 */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private CompanySize companySize;

    /** 자산 규모 참고 구간 (공식 분류와 별도 필드) */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private AssetBand assetBand;

    @Column(length = 50)
    private String region;

    @Column(length = 100)
    private String industry;

    private Integer regularWorkerCount;

    /** 규모 분류 출처 (예: "고용24 강소기업 API") */
    @Column(length = 100)
    private String sizeSource;

    /** 규모 분류 기준일 */
    private LocalDate sizeBaseDate;

    protected Company() {
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public CompanySize getCompanySize() {
        return companySize;
    }

    public AssetBand getAssetBand() {
        return assetBand;
    }

    public String getRegion() {
        return region;
    }

    public String getIndustry() {
        return industry;
    }

    public Integer getRegularWorkerCount() {
        return regularWorkerCount;
    }

    public String getSizeSource() {
        return sizeSource;
    }

    public LocalDate getSizeBaseDate() {
        return sizeBaseDate;
    }
}
