package com.reccal.company;

import com.reccal.common.response.ApiResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.Arrays;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "3. 기업 규모 필터")
@RestController
@RequestMapping("/api/meta")
public class CompanyMetaController {

    public record CompanySizeOption(String code, String label) {
    }

    public record AssetBandOption(String code, String label, String condition) {
    }

    @Operation(summary = "기업 규모 선택지", description = "화면의 기업 규모 체크박스용. 복수 선택 가능, 미선택 시 전체")
    @GetMapping("/company-sizes")
    public ApiResponse<List<CompanySizeOption>> companySizes() {
        return ApiResponse.ok(Arrays.stream(CompanySize.values())
                .map(s -> new CompanySizeOption(s.name(), s.getLabel())).toList());
    }

    @Operation(summary = "자산 규모 참고 구간 선택지", description = "공식 판정 기준이 아닌 참고용 필터")
    @GetMapping("/asset-bands")
    public ApiResponse<List<AssetBandOption>> assetBands() {
        return ApiResponse.ok(Arrays.stream(AssetBand.values())
                .map(b -> new AssetBandOption(b.name(), b.getLabel(), b.getCondition())).toList());
    }
}
