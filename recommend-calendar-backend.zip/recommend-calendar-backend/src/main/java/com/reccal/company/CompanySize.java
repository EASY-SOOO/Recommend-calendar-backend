package com.reccal.company;

/**
 * 공식 기업 규모 분류. 제공기관의 공식 분류·확인정보가 있을 때만 SME/MID/LARGE를 사용하고,
 * 자료가 없거나 세 분류에 해당하지 않으면 추정하지 않고 UNKNOWN으로 둔다. (설계서 2.1)
 */
public enum CompanySize {
    SME("중소기업"),
    MID("중견기업"),
    LARGE("대기업"),
    UNKNOWN("미확인·기타");

    private final String label;

    CompanySize(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
