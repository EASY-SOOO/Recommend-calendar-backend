package com.reccal.field;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/** 관심 분야 대분류 (설계서 3.1의 8개 분야). 시드 데이터로 고정 관리하므로 ID를 직접 지정한다. */
@Entity
@Table(name = "field_category")
public class FieldCategory {

    @Id
    private Long id;

    @Column(nullable = false, unique = true, length = 30)
    private String code;

    @Column(nullable = false, length = 50)
    private String name;

    @Column(length = 200)
    private String description;

    /** 1차 분야 기초 CBT를 제공하는 대표 분야인지 (최소 기능은 3~4개) */
    @Column(nullable = false)
    private boolean cbtSupported;

    protected FieldCategory() {
    }

    public Long getId() {
        return id;
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCbtSupported() {
        return cbtSupported;
    }
}
