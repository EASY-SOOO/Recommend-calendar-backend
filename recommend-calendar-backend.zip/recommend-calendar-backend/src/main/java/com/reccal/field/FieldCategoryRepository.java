package com.reccal.field;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FieldCategoryRepository extends JpaRepository<FieldCategory, Long> {

    List<FieldCategory> findAllByOrderByIdAsc();
}
