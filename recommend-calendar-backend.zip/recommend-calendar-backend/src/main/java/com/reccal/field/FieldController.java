package com.reccal.field;

import com.reccal.common.response.ApiResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "2. 관심 분야")
@RestController
@RequestMapping("/api/fields")
public class FieldController {

    private final FieldCategoryRepository repository;

    public FieldController(FieldCategoryRepository repository) {
        this.repository = repository;
    }

    @Operation(summary = "관심 분야 목록", description = "8개 대분류. cbtSupported=true인 분야만 1차 기초 CBT를 제공")
    @GetMapping
    @Transactional(readOnly = true)
    public ApiResponse<List<FieldResponse>> list() {
        return ApiResponse.ok(repository.findAllByOrderByIdAsc().stream().map(FieldResponse::from).toList());
    }
}
