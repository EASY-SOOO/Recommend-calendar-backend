package com.reccal.field;

public record FieldResponse(Long id, String code, String name, String description, boolean cbtSupported) {

    public static FieldResponse from(FieldCategory f) {
        return new FieldResponse(f.getId(), f.getCode(), f.getName(), f.getDescription(), f.isCbtSupported());
    }
}
