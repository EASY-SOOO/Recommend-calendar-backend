package com.reccal.jobposting.controller;

import com.reccal.common.response.ApiResponse;
import com.reccal.company.AssetBand;
import com.reccal.company.CompanySize;
import com.reccal.jobposting.dto.JobPostingFilter;
import com.reccal.jobposting.dto.JobPostingSearchResponse;
import com.reccal.jobposting.service.JobPostingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import java.util.Set;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "4. 채용공고")
@RestController
@RequestMapping("/api/job-postings")
public class JobPostingController {

    private final JobPostingService jobPostingService;

    public JobPostingController(JobPostingService jobPostingService) {
        this.jobPostingService = jobPostingService;
    }

    @Operation(summary = "채용공고 필터 조회",
            description = "관심 분야(최대 3개) + 희망 기업 규모(복수) + 자산 참고 구간(선택). 값을 비우면 해당 조건은 전체.\n"
                    + "예: /api/job-postings?fieldIds=1,3&companySizes=SME,MID")
    @GetMapping
    public ApiResponse<JobPostingSearchResponse> search(
            @Parameter(description = "관심 분야 ID (최대 3개)") @RequestParam(required = false) List<Long> fieldIds,
            @Parameter(description = "기업 규모: SME, MID, LARGE, UNKNOWN") @RequestParam(required = false)
            Set<CompanySize> companySizes,
            @Parameter(description = "자산 참고 구간 (선택)") @RequestParam(required = false) Set<AssetBand> assetBands) {
        return ApiResponse.ok(jobPostingService.search(new JobPostingFilter(fieldIds, companySizes, assetBands)));
    }
}
