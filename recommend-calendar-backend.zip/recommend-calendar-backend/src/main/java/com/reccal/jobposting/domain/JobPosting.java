package com.reccal.jobposting.domain;

import com.reccal.company.Company;
import com.reccal.field.FieldCategory;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "job_posting")
public class JobPosting {

    @Id
    private Long id;

    @Column(nullable = false, length = 200)
    private String title;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "company_id", nullable = false)
    private Company company;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "field_id", nullable = false)
    private FieldCategory field;

    /** 데이터 출처 (예: "고용24", "샘플") */
    @Column(length = 100)
    private String source;

    private LocalDate postedDate;

    @Column(length = 500)
    private String url;

    @OneToMany(mappedBy = "jobPosting")
    private List<JobPostingCertificate> certificates = new ArrayList<>();

    protected JobPosting() {
    }

    public Long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public Company getCompany() {
        return company;
    }

    public FieldCategory getField() {
        return field;
    }

    public String getSource() {
        return source;
    }

    public LocalDate getPostedDate() {
        return postedDate;
    }

    public String getUrl() {
        return url;
    }

    public List<JobPostingCertificate> getCertificates() {
        return certificates;
    }
}
