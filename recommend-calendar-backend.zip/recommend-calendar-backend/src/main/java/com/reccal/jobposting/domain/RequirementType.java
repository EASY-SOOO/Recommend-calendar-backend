package com.reccal.jobposting.domain;

public enum RequirementType {
    REQUIRED("필수"),
    PREFERRED("우대");

    private final String label;

    RequirementType(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
