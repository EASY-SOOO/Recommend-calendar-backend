package com.reccal.jobposting.dto;

import com.reccal.company.AssetBand;
import com.reccal.company.CompanySize;
import java.util.List;
import java.util.Set;

/** 채용공고 필터. null은 빈 컬렉션(= 조건 미적용)으로 정규화한다. */
public record JobPostingFilter(List<Long> fieldIds, Set<CompanySize> companySizes, Set<AssetBand> assetBands) {

    public static final int MAX_FIELDS = 3;

    public JobPostingFilter {
        fieldIds = fieldIds == null ? List.of() : List.copyOf(fieldIds);
        companySizes = companySizes == null ? Set.of() : Set.copyOf(companySizes);
        assetBands = assetBands == null ? Set.of() : Set.copyOf(assetBands);
        if (fieldIds.size() > MAX_FIELDS) {
            throw new IllegalArgumentException("관심 분야는 최대 " + MAX_FIELDS + "개까지 선택할 수 있습니다.");
        }
    }
}
