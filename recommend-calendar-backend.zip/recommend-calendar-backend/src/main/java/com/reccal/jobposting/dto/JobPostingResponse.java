package com.reccal.jobposting.dto;

import com.reccal.jobposting.domain.JobPosting;
import java.time.LocalDate;
import java.util.List;

public record JobPostingResponse(
        Long id,
        String title,
        String fieldName,
        CompanyInfo company,
        List<CertificateRequirement> certificates,
        String source,
        LocalDate postedDate) {

    public record CompanyInfo(Long id, String name, String companySize, String companySizeLabel,
                              String assetBand, String sizeSource, LocalDate sizeBaseDate) {
    }

    public record CertificateRequirement(Long certificateId, String name, String requirementType,
                                         String requirementLabel) {
    }

    public static JobPostingResponse from(JobPosting p) {
        var c = p.getCompany();
        CompanyInfo company = new CompanyInfo(c.getId(), c.getName(), c.getCompanySize().name(),
                c.getCompanySize().getLabel(), c.getAssetBand().name(), c.getSizeSource(), c.getSizeBaseDate());
        List<CertificateRequirement> certs = p.getCertificates().stream()
                .map(pc -> new CertificateRequirement(pc.getCertificate().getId(), pc.getCertificate().getName(),
                        pc.getRequirementType().name(), pc.getRequirementType().getLabel()))
                .toList();
        return new JobPostingResponse(p.getId(), p.getTitle(), p.getField().getName(), company, certs,
                p.getSource(), p.getPostedDate());
    }
}
