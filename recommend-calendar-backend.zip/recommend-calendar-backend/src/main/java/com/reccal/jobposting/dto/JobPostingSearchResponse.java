package com.reccal.jobposting.dto;

import java.util.List;
import java.util.Map;

/**
 * @param countByCompanySize 결과 공고의 기업 규모별 개수 (미확인 공고가 몇 건인지 화면에 따로 표시하기 위함)
 */
public record JobPostingSearchResponse(
        int totalCount,
        Map<String, Long> countByCompanySize,
        List<JobPostingResponse> postings) {
}
