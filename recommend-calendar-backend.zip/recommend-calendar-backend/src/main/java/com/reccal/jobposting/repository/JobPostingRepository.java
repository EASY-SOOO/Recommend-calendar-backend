package com.reccal.jobposting.repository;

import com.reccal.jobposting.domain.JobPosting;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface JobPostingRepository extends JpaRepository<JobPosting, Long>, JpaSpecificationExecutor<JobPosting> {

    @Override
    @EntityGraph(attributePaths = {"company", "field"})
    List<JobPosting> findAll(Specification<JobPosting> spec, Sort sort);
}
