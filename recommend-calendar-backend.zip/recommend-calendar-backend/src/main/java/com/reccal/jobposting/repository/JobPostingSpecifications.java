package com.reccal.jobposting.repository;

import com.reccal.jobposting.dto.JobPostingFilter;
import com.reccal.jobposting.domain.JobPosting;
import jakarta.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.List;
import org.springframework.data.jpa.domain.Specification;

/**
 * 채용공고 필터 조건. 각 조건은 값이 비어 있으면 적용하지 않는다(= 전체).
 * - 관심 분야: field.id IN (...)
 * - 기업 규모: company.companySize IN (...)  ← UNKNOWN은 사용자가 직접 선택했을 때만 포함
 * - 자산 참고 구간: company.assetBand IN (...)
 */
public final class JobPostingSpecifications {

    private JobPostingSpecifications() {
    }

    public static Specification<JobPosting> matches(JobPostingFilter filter) {
        return (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();
            if (!filter.fieldIds().isEmpty()) {
                predicates.add(root.get("field").get("id").in(filter.fieldIds()));
            }
            if (!filter.companySizes().isEmpty()) {
                predicates.add(root.get("company").get("companySize").in(filter.companySizes()));
            }
            if (!filter.assetBands().isEmpty()) {
                predicates.add(root.get("company").get("assetBand").in(filter.assetBands()));
            }
            return cb.and(predicates.toArray(new Predicate[0]));
        };
    }
}
