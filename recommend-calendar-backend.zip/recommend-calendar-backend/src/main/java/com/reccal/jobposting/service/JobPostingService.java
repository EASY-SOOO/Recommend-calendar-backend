package com.reccal.jobposting.service;

import com.reccal.jobposting.domain.JobPosting;
import com.reccal.jobposting.dto.JobPostingFilter;
import com.reccal.jobposting.dto.JobPostingResponse;
import com.reccal.jobposting.dto.JobPostingSearchResponse;
import com.reccal.jobposting.repository.JobPostingRepository;
import com.reccal.jobposting.repository.JobPostingSpecifications;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(readOnly = true)
public class JobPostingService {

    private final JobPostingRepository jobPostingRepository;

    public JobPostingService(JobPostingRepository jobPostingRepository) {
        this.jobPostingRepository = jobPostingRepository;
    }

    /** 추천 로직 등 내부에서 쓰는 엔티티 조회 */
    public List<JobPosting> findPostings(JobPostingFilter filter) {
        return jobPostingRepository.findAll(JobPostingSpecifications.matches(filter),
                Sort.by(Sort.Order.desc("postedDate"), Sort.Order.asc("id")));
    }

    public JobPostingSearchResponse search(JobPostingFilter filter) {
        List<JobPosting> postings = findPostings(filter);
        Map<String, Long> countBySize = postings.stream()
                .collect(Collectors.groupingBy(p -> p.getCompany().getCompanySize().name(), TreeMap::new,
                        Collectors.counting()));
        return new JobPostingSearchResponse(postings.size(), new LinkedHashMap<>(countBySize),
                postings.stream().map(JobPostingResponse::from).toList());
    }
}
