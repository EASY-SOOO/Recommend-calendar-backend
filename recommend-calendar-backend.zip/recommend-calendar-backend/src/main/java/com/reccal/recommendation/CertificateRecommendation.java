package com.reccal.recommendation;

import java.time.LocalDate;

/**
 * @param postingCount   이 자격증이 등장한 공고 수
 * @param appearanceRate 필터된 전체 공고 중 등장 비율 (0.0~1.0)
 * @param score          추천 점수 (현재: 필수 2점 + 우대 1점, 2번 알고리즘으로 교체 예정)
 */
public record CertificateRecommendation(
        int rank,
        Long certificateId,
        String name,
        String fieldName,
        int postingCount,
        int requiredCount,
        int preferredCount,
        double appearanceRate,
        double score,
        Double averagePassRate,
        boolean mockDiagnosisSupported,
        LocalDate nextExamDate) {
}
