package com.reccal.recommendation;

import com.reccal.jobposting.domain.JobPosting;
import java.util.List;

/**
 * 자격증 추천 알고리즘 인터페이스.
 * 1번(Backend)은 API와 데이터 조회를, 2번(추천 로직)은 이 인터페이스의 구현체를 담당한다.
 * 2번이 새 구현체를 만들고 @Primary를 붙이면 Controller 수정 없이 교체된다.
 */
public interface CertificateRecommender {

    List<CertificateRecommendation> recommend(List<JobPosting> filteredPostings, int limit);
}
