package com.reccal.recommendation;

import com.reccal.certificate.domain.Certificate;
import com.reccal.certificate.service.CertificateService;
import com.reccal.jobposting.domain.JobPosting;
import com.reccal.jobposting.domain.JobPostingCertificate;
import com.reccal.jobposting.domain.RequirementType;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Component;

/**
 * 기본(초안) 추천: 필터된 공고에서 자격증 등장 빈도와 필수·우대 여부로 점수를 매긴다.
 * score = 필수 등장 수 × 2 + 우대 등장 수 × 1. 동점이면 등장 공고 수, 그다음 ID 순.
 */
@Component
public class FrequencyBasedRecommender implements CertificateRecommender {

    static final double REQUIRED_WEIGHT = 2.0;
    static final double PREFERRED_WEIGHT = 1.0;

    private final CertificateService certificateService;

    public FrequencyBasedRecommender(CertificateService certificateService) {
        this.certificateService = certificateService;
    }

    private static final class Tally {
        final Certificate certificate;
        int required;
        int preferred;

        Tally(Certificate certificate) {
            this.certificate = certificate;
        }

        int postings() {
            return required + preferred;
        }

        double score() {
            return required * REQUIRED_WEIGHT + preferred * PREFERRED_WEIGHT;
        }
    }

    @Override
    public List<CertificateRecommendation> recommend(List<JobPosting> filteredPostings, int limit) {
        Map<Long, Tally> tallies = new LinkedHashMap<>();
        for (JobPosting posting : filteredPostings) {
            for (JobPostingCertificate pc : posting.getCertificates()) {
                Tally t = tallies.computeIfAbsent(pc.getCertificate().getId(), id -> new Tally(pc.getCertificate()));
                if (pc.getRequirementType() == RequirementType.REQUIRED) {
                    t.required++;
                } else {
                    t.preferred++;
                }
            }
        }

        List<Tally> sorted = new ArrayList<>(tallies.values());
        sorted.sort(Comparator.comparingDouble(Tally::score).reversed()
                .thenComparing(Comparator.comparingInt(Tally::postings).reversed())
                .thenComparing(t -> t.certificate.getId()));

        int total = filteredPostings.size();
        List<CertificateRecommendation> result = new ArrayList<>();
        for (int i = 0; i < Math.min(limit, sorted.size()); i++) {
            Tally t = sorted.get(i);
            Certificate c = t.certificate;
            double rate = total == 0 ? 0.0 : Math.round(t.postings() * 1000.0 / total) / 1000.0;
            result.add(new CertificateRecommendation(i + 1, c.getId(), c.getName(), c.getField().getName(),
                    t.postings(), t.required, t.preferred, rate, t.score(), c.getAveragePassRate(),
                    c.isMockDiagnosisSupported(), certificateService.nextExamDate(c.getId())));
        }
        return result;
    }
}
