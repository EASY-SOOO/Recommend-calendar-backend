package com.reccal.recommendation;

import com.reccal.common.response.ApiResponse;
import com.reccal.company.AssetBand;
import com.reccal.company.CompanySize;
import com.reccal.jobposting.dto.JobPostingFilter;
import com.reccal.jobposting.service.JobPostingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import java.util.List;
import java.util.Set;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "6. 자격증 추천")
@Validated
@RestController
@RequestMapping("/api/recommendations")
public class RecommendationController {

    public record RecommendationResponse(int analyzedPostingCount, String algorithm,
                                         List<CertificateRecommendation> recommendations) {
    }

    private final JobPostingService jobPostingService;
    private final CertificateRecommender recommender;

    public RecommendationController(JobPostingService jobPostingService, CertificateRecommender recommender) {
        this.jobPostingService = jobPostingService;
        this.recommender = recommender;
    }

    @Operation(summary = "채용공고 기반 자격증 추천",
            description = "채용공고 필터와 같은 조건으로 공고를 고른 뒤, 공고에 등장한 자격증을 필수·우대·빈도로 순위화")
    @GetMapping("/certificates")
    @Transactional(readOnly = true)
    public ApiResponse<RecommendationResponse> recommend(
            @RequestParam(required = false) List<Long> fieldIds,
            @RequestParam(required = false) Set<CompanySize> companySizes,
            @RequestParam(required = false) Set<AssetBand> assetBands,
            @RequestParam(defaultValue = "10") @Min(1) @Max(50) int limit) {
        var postings = jobPostingService.findPostings(new JobPostingFilter(fieldIds, companySizes, assetBands));
        return ApiResponse.ok(new RecommendationResponse(postings.size(),
                recommender.getClass().getSimpleName(), recommender.recommend(postings, limit)));
    }
}
