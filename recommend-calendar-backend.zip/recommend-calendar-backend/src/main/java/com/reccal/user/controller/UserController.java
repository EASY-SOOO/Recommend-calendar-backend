package com.reccal.user.controller;

import com.reccal.common.response.ApiResponse;
import com.reccal.user.dto.AvailabilityRequest;
import com.reccal.user.dto.PreferenceRequest;
import com.reccal.user.dto.UserResponse;
import com.reccal.user.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "1. 회원")
@RestController
@RequestMapping("/api/users/me")
public class UserController {

    public static final String USER_HEADER = "X-User-Id";

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @Operation(summary = "내 정보 조회", description = "관심 분야, 희망 기업 규모, 요일별 공부 가능 시간 포함")
    @GetMapping
    public ApiResponse<UserResponse> me(@RequestHeader(USER_HEADER) Long userId) {
        return ApiResponse.ok(userService.getMe(userId));
    }

    @Operation(summary = "관심 분야·희망 기업 규모 설정", description = "관심 분야 1~3개, 기업 규모 복수 선택(비우면 전체)")
    @PutMapping("/preferences")
    public ApiResponse<UserResponse> updatePreferences(@RequestHeader(USER_HEADER) Long userId,
                                                       @Valid @RequestBody PreferenceRequest request) {
        return ApiResponse.ok(userService.updatePreferences(userId, request));
    }

    @Operation(summary = "요일별 공부 가능 시간 설정", description = "예: {\"minutesByDay\": {\"MONDAY\": 120, \"SATURDAY\": 240}}")
    @PutMapping("/availability")
    public ApiResponse<UserResponse> updateAvailability(@RequestHeader(USER_HEADER) Long userId,
                                                        @Valid @RequestBody AvailabilityRequest request) {
        return ApiResponse.ok(userService.updateAvailability(userId, request));
    }
}
