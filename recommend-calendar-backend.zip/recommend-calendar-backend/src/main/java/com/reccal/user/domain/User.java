package com.reccal.user.domain;

import com.reccal.company.CompanySize;
import jakarta.persistence.CollectionTable;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.MapKeyColumn;
import jakarta.persistence.MapKeyEnumerated;
import jakarta.persistence.Table;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 100)
    private String email;

    @Column(nullable = false)
    private String passwordHash;

    @Column(nullable = false, length = 30)
    private String nickname;

    /** 관심 분야 ID (1~3개) */
    @ElementCollection
    @CollectionTable(name = "user_interest_field", joinColumns = @JoinColumn(name = "user_id"))
    @Column(name = "field_id", nullable = false)
    private Set<Long> interestFieldIds = new LinkedHashSet<>();

    /** 희망 기업 규모 (비어 있으면 전체) */
    @ElementCollection
    @CollectionTable(name = "user_company_size", joinColumns = @JoinColumn(name = "user_id"))
    @Enumerated(EnumType.STRING)
    @Column(name = "company_size", nullable = false, length = 20)
    private Set<CompanySize> preferredCompanySizes = new LinkedHashSet<>();

    /** 요일별 공부 가능 시간(분) — 일정 생성에 사용 */
    @ElementCollection
    @CollectionTable(name = "user_weekly_availability", joinColumns = @JoinColumn(name = "user_id"))
    @MapKeyEnumerated(EnumType.STRING)
    @MapKeyColumn(name = "day_of_week", length = 10)
    @Column(name = "available_minutes", nullable = false)
    private Map<DayOfWeek, Integer> weeklyAvailableMinutes = new LinkedHashMap<>();

    @Column(nullable = false)
    private LocalDateTime createdAt;

    protected User() {
    }

    public User(String email, String passwordHash, String nickname) {
        this.email = email;
        this.passwordHash = passwordHash;
        this.nickname = nickname;
        this.createdAt = LocalDateTime.now();
    }

    public void updatePreferences(Collection<Long> fieldIds, Collection<CompanySize> companySizes) {
        interestFieldIds.clear();
        interestFieldIds.addAll(fieldIds);
        preferredCompanySizes.clear();
        if (companySizes != null) {
            preferredCompanySizes.addAll(companySizes);
        }
    }

    public void updateAvailability(Map<DayOfWeek, Integer> minutesByDay) {
        weeklyAvailableMinutes.clear();
        weeklyAvailableMinutes.putAll(minutesByDay);
    }

    public Long getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public String getNickname() {
        return nickname;
    }

    public Set<Long> getInterestFieldIds() {
        return interestFieldIds;
    }

    public Set<CompanySize> getPreferredCompanySizes() {
        return preferredCompanySizes;
    }

    public Map<DayOfWeek, Integer> getWeeklyAvailableMinutes() {
        return weeklyAvailableMinutes;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}
