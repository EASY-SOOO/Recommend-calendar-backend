package com.reccal.user.dto;

import jakarta.validation.constraints.NotNull;
import java.time.DayOfWeek;
import java.util.Map;

/**
 * 요일별 공부 가능 시간(분). 예: { "MONDAY": 120, "SATURDAY": 240 }
 * 빠진 요일은 0분으로 본다.
 */
public record AvailabilityRequest(@NotNull Map<DayOfWeek, Integer> minutesByDay) {
}
