package com.reccal.user.dto;

/** 임시: JWT 도입 전까지 userId를 돌려주고, 클라이언트는 X-User-Id 헤더로 전달한다. */
public record LoginResponse(Long userId, String nickname) {
}
