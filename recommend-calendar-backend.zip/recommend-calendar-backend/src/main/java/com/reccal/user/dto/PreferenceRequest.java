package com.reccal.user.dto;

import com.reccal.company.CompanySize;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.List;
import java.util.Set;

/**
 * @param fieldIds     관심 분야 1~3개
 * @param companySizes 희망 기업 규모 (비우면 전체)
 */
public record PreferenceRequest(
        @NotNull @Size(min = 1, max = 3) List<Long> fieldIds,
        Set<CompanySize> companySizes) {
}
