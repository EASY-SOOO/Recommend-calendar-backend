package com.reccal.user.dto;

import com.reccal.user.domain.User;
import java.time.DayOfWeek;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public record UserResponse(
        Long id,
        String email,
        String nickname,
        List<Long> interestFieldIds,
        List<String> preferredCompanySizes,
        Map<DayOfWeek, Integer> weeklyAvailableMinutes,
        int weeklyTotalMinutes) {

    public static UserResponse from(User u) {
        Map<DayOfWeek, Integer> week = new LinkedHashMap<>();
        for (DayOfWeek d : DayOfWeek.values()) {
            week.put(d, u.getWeeklyAvailableMinutes().getOrDefault(d, 0));
        }
        int total = week.values().stream().mapToInt(Integer::intValue).sum();
        return new UserResponse(u.getId(), u.getEmail(), u.getNickname(),
                u.getInterestFieldIds().stream().sorted().toList(),
                u.getPreferredCompanySizes().stream().map(Enum::name).sorted().toList(),
                week, total);
    }
}
