package com.reccal.user.service;

import com.reccal.common.exception.BusinessException;
import com.reccal.common.exception.ErrorCode;
import com.reccal.field.FieldCategoryRepository;
import com.reccal.user.domain.User;
import com.reccal.user.dto.AvailabilityRequest;
import com.reccal.user.dto.LoginRequest;
import com.reccal.user.dto.LoginResponse;
import com.reccal.user.dto.PreferenceRequest;
import com.reccal.user.dto.SignupRequest;
import com.reccal.user.dto.UserResponse;
import com.reccal.user.repository.UserRepository;
import java.time.DayOfWeek;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional(readOnly = true)
public class UserService {

    private static final int MAX_MINUTES_PER_DAY = 24 * 60;

    private final UserRepository userRepository;
    private final FieldCategoryRepository fieldRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, FieldCategoryRepository fieldRepository,
                       PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.fieldRepository = fieldRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Transactional
    public UserResponse signup(SignupRequest request) {
        String email = request.email().trim().toLowerCase();
        if (userRepository.existsByEmail(email)) {
            throw new BusinessException(ErrorCode.DUPLICATE_EMAIL);
        }
        User user = userRepository.save(new User(email, passwordEncoder.encode(request.password()),
                request.nickname().trim()));
        return UserResponse.from(user);
    }

    public LoginResponse login(LoginRequest request) {
        User user = userRepository.findByEmail(request.email().trim().toLowerCase())
                .filter(u -> passwordEncoder.matches(request.password(), u.getPasswordHash()))
                .orElseThrow(() -> new BusinessException(ErrorCode.LOGIN_FAILED));
        return new LoginResponse(user.getId(), user.getNickname());
    }

    public UserResponse getMe(Long userId) {
        return UserResponse.from(getUser(userId));
    }

    @Transactional
    public UserResponse updatePreferences(Long userId, PreferenceRequest request) {
        Set<Long> fieldIds = new LinkedHashSet<>(request.fieldIds());
        for (Long fieldId : fieldIds) {
            if (fieldId == null || !fieldRepository.existsById(fieldId)) {
                throw new BusinessException(ErrorCode.FIELD_NOT_FOUND, "존재하지 않는 관심 분야입니다: " + fieldId);
            }
        }
        User user = getUser(userId);
        user.updatePreferences(fieldIds, request.companySizes());
        return UserResponse.from(user);
    }

    @Transactional
    public UserResponse updateAvailability(Long userId, AvailabilityRequest request) {
        for (Map.Entry<DayOfWeek, Integer> e : request.minutesByDay().entrySet()) {
            Integer minutes = e.getValue();
            if (minutes == null || minutes < 0 || minutes > MAX_MINUTES_PER_DAY) {
                throw new BusinessException(ErrorCode.INVALID_INPUT,
                        e.getKey() + " 공부 가능 시간은 0~" + MAX_MINUTES_PER_DAY + "분이어야 합니다.");
            }
        }
        User user = getUser(userId);
        user.updateAvailability(request.minutesByDay());
        return UserResponse.from(user);
    }

    public User getUser(Long userId) {
        return userRepository.findById(userId).orElseThrow(() -> new BusinessException(ErrorCode.USER_NOT_FOUND));
    }
}
