package com.reccal;

import static org.hamcrest.Matchers.everyItem;
import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

/** 4번 GitHub Actions에서 ./gradlew test로 돌아가는 기본 동작 확인 테스트 (H2 + data.sql) */
@SpringBootTest
@AutoConfigureMockMvc
class ApiSmokeTest {

    @Autowired
    MockMvc mvc;

    @Autowired
    ObjectMapper objectMapper;

    @Test
    void 관심분야_8개를_조회한다() throws Exception {
        mvc.perform(get("/api/fields"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success", is(true)))
                .andExpect(jsonPath("$.data.length()", is(8)));
    }

    @Test
    void 기업규모_필터는_선택한_규모의_공고만_돌려준다() throws Exception {
        mvc.perform(get("/api/job-postings").param("fieldIds", "1").param("companySizes", "SME"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.totalCount", is(3)))
                .andExpect(jsonPath("$.data.postings[*].company.companySize", everyItem(is("SME"))));
    }

    @Test
    void 기업규모를_선택하지_않으면_미확인_기업을_포함한_전체를_돌려준다() throws Exception {
        mvc.perform(get("/api/job-postings").param("fieldIds", "1"))
                .andExpect(jsonPath("$.data.totalCount", is(7)))
                .andExpect(jsonPath("$.data.countByCompanySize.UNKNOWN", is(1)));

        mvc.perform(get("/api/job-postings").param("fieldIds", "1").param("companySizes", "SME,MID,LARGE"))
                .andExpect(jsonPath("$.data.totalCount", is(6)));
    }

    @Test
    void 관심분야는_최대_3개() throws Exception {
        mvc.perform(get("/api/job-postings").param("fieldIds", "1,2,3,4"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.error.code", is("INVALID_INPUT")));
    }

    @Test
    void 자격증_추천은_필수_우대_빈도로_순위를_매긴다() throws Exception {
        mvc.perform(get("/api/recommendations/certificates").param("fieldIds", "1").param("companySizes", "SME"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.analyzedPostingCount", is(3)))
                .andExpect(jsonPath("$.data.recommendations[0].name", is("정보처리기사")))
                .andExpect(jsonPath("$.data.recommendations[0].postingCount", is(3)))
                .andExpect(jsonPath("$.data.recommendations[0].requiredCount", is(1)))
                .andExpect(jsonPath("$.data.recommendations[0].score", is(4.0)));
    }

    @Test
    void 회원가입부터_캘린더까지_흐름() throws Exception {
        String signup = """
                {"email":"flow@test.com","password":"password123","nickname":"테스터"}""";
        mvc.perform(post("/api/auth/signup").contentType(MediaType.APPLICATION_JSON).content(signup))
                .andExpect(status().isCreated());

        String login = mvc.perform(post("/api/auth/login").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"flow@test.com\",\"password\":\"password123\"}"))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        String userId = objectMapper.readTree(login).path("data").path("userId").asText();

        mvc.perform(put("/api/users/me/preferences").header("X-User-Id", userId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"fieldIds\":[1,3],\"companySizes\":[\"SME\",\"MID\"]}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.interestFieldIds.length()", is(2)));

        mvc.perform(put("/api/users/me/availability").header("X-User-Id", userId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"minutesByDay\":{\"MONDAY\":120,\"SATURDAY\":240}}"))
                .andExpect(jsonPath("$.data.weeklyTotalMinutes", is(360)));

        String created = mvc.perform(post("/api/calendar/events").header("X-User-Id", userId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"title\":\"SQL 개념 복습\",\"date\":\"2026-10-20\",\"plannedMinutes\":120,"
                                + "\"type\":\"STUDY\",\"certificateId\":1}"))
                .andExpect(status().isCreated())
                .andReturn().getResponse().getContentAsString();
        JsonNode event = objectMapper.readTree(created).path("data");
        long eventId = event.path("id").asLong();

        mvc.perform(patch("/api/calendar/events/" + eventId).header("X-User-Id", userId)
                        .contentType(MediaType.APPLICATION_JSON).content("{\"completed\":true}"))
                .andExpect(jsonPath("$.data.completed", is(true)));

        mvc.perform(get("/api/calendar/events").header("X-User-Id", userId)
                        .param("from", "2026-10-01").param("to", "2026-10-31"))
                .andExpect(jsonPath("$.data.length()", is(1)));

        mvc.perform(patch("/api/calendar/events/" + eventId).header("X-User-Id", "999999")
                        .contentType(MediaType.APPLICATION_JSON).content("{\"completed\":false}"))
                .andExpect(status().isForbidden());

        mvc.perform(delete("/api/calendar/events/" + eventId).header("X-User-Id", userId))
                .andExpect(status().isOk());
    }

    @Test
    void X_User_Id_헤더가_없으면_401() throws Exception {
        mvc.perform(get("/api/users/me"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.error.code", is("MISSING_USER_HEADER")));
    }
}
